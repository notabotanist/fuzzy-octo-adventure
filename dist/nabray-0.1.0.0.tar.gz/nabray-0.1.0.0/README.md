fuzzy-octo-adventure
====================

Haskell Ray Tracer

# Build Instructions
1. Extract `nabray-0.1.0.0.tar.gz` to a new directory.
2. In that directory, execute the following commands:
    cabal configure --ghc
    cabal build
You should be prompted to install some required libraries.
3. Execute `dist/build/nabray/nabray` to render example images.
